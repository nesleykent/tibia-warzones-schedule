#!/usr/bin/env python3
"""Reproducible Tibia Coin market panel, forecasts, and report-ready tables."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lxml import html


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
SOURCE = WORK / "source-repo"
DATA = WORK / "analysis"
DATA.mkdir(parents=True, exist_ok=True)

START = pd.Timestamp("2023-01-11", tz="UTC")
END = pd.Timestamp("2026-07-29", tz="UTC")
REGION_FACTORS = {
    "Europe": 2.47,
    "South America": 1.57,
    "Oceania": 1.07,
    "North America": 0.80,
}
HORIZONS = {14: "2 weeks", 30: "1 month", 90: "3 months", 180: "6 months"}


def num(v):
    if v is None or v == -1:
        return np.nan
    try:
        return float(v)
    except (TypeError, ValueError):
        return np.nan


def parse_world_metadata() -> pd.DataFrame:
    with open(WORK / "worlds.json", encoding="utf-8") as fh:
        api = json.load(fh)["worlds"]["regular_worlds"]
    api_df = pd.DataFrame(api)

    tables = pd.read_html(WORK / "guildstats_worlds.html")
    guild = tables[0].rename(
        columns={
            "World name": "name",
            "Created": "created",
            "Record online": "record_online",
            "Loc. Location": "guildstats_location",
        }
    )
    guild["created"] = pd.to_datetime(guild["created"], errors="coerce")
    guild = guild[["name", "created", "record_online"]]

    merge_doc = html.parse(str(WORK / "guildstats_merges.html"))
    cards = merge_doc.xpath(
        '//div[contains(@class,"overflow-hidden") and '
        './/div[contains(normalize-space(),"Merged worlds")]]'
    )
    merge_rows = []
    for card in cards:
        txt = [x.strip() for x in card.xpath(".//text()") if x.strip()]
        # [#n, successor, merge_date, region, Merged worlds, pred, created, ...]
        if len(txt) < 7 or "Merged worlds" not in txt:
            continue
        idx = txt.index("Merged worlds")
        preds = txt[idx + 1 :]
        merge_rows.append(
            {
                "successor": txt[1],
                "merge_date": pd.to_datetime(txt[2], dayfirst=True, errors="coerce"),
                "region": txt[3],
                "predecessors": " | ".join(preds[0::2]),
                "predecessor_creation_dates": " | ".join(preds[1::2]),
                "predecessor_count": len(preds[0::2]),
            }
        )
    merges = pd.DataFrame(merge_rows).sort_values("merge_date")
    merges.to_csv(DATA / "world_merge_register.csv", index=False)

    meta = api_df.merge(guild, on="name", how="left")
    meta = meta.merge(
        merges.rename(columns={"successor": "name"})[
            ["name", "merge_date", "predecessors", "predecessor_count"]
        ],
        on="name",
        how="left",
    )
    meta["merge_flag"] = meta["merge_date"].notna()
    meta["snapshot_population"] = meta["players_online"].astype(float)
    meta["population_factor"] = meta["location"].map(REGION_FACTORS)
    meta["corrected_population_estimate"] = (
        meta["snapshot_population"] * meta["population_factor"]
    )
    meta["created_utc"] = pd.to_datetime(meta["created"], utc=True)
    meta["age_years_at_end"] = (END - meta["created_utc"]).dt.days / 365.2425
    meta["launch_in_window"] = (
        meta["created_utc"].between(START, END) & ~meta["merge_flag"]
    )
    meta["battleye_cohort"] = np.where(
        meta["battleye_date"].eq("release"), "Protected since release", "Retrofitted"
    )
    return meta, merges


def parse_transfers() -> pd.DataFrame:
    doc = html.parse(str(WORK / "guildstats_transfers.html"))
    rows = []
    for tr in doc.xpath('//table[@id="transferTable"]/tbody/tr'):
        cells = []
        for td in tr.xpath("./td"):
            texts = [x.strip() for x in td.xpath(".//text()") if x.strip()]
            cells.append(texts)
        if len(cells) < 7:
            continue
        rows.append(
            {
                "name": cells[1][0] if cells[1] else "",
                "level": int(cells[2][0].replace(",", "")) if cells[2] else np.nan,
                "vocation": cells[3][0] if cells[3] else "",
                "former_world": cells[4][-1] if cells[4] else "",
                "current_world": cells[5][-1] if cells[5] else "",
                "change_date": cells[6][-1] if cells[6] else "",
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["change_date"] = pd.to_datetime(df["change_date"], errors="coerce")
    df.to_csv(DATA / "recent_character_transfers.csv", index=False)
    return df


def construct_row_price(row):
    sell = (
        num(row.get("day_average_sell"))
        if num(row.get("day_sold")) > 0 and num(row.get("day_average_sell")) > 1000
        else np.nan
    )
    buy = (
        num(row.get("day_average_buy"))
        if num(row.get("day_bought")) > 0 and num(row.get("day_average_buy")) > 1000
        else np.nan
    )
    vals = [v for v in [sell, buy] if np.isfinite(v)]
    if vals:
        return float(np.mean(vals)), "executed-average"
    bid, ask = num(row.get("buy_offer")), num(row.get("sell_offer"))
    if np.isfinite(bid) and np.isfinite(ask) and bid > 0 and 0.5 <= ask / bid <= 2.0:
        return (bid + ask) / 2.0, "order-book-mid-fallback"
    return np.nan, "missing"


def load_panel(meta: pd.DataFrame) -> pd.DataFrame:
    records = []
    paths = sorted((SOURCE / "data/market/world").glob("*/*_tibia_coins.json"))
    for path in paths:
        world = path.parent.name
        with open(path, encoding="utf-8") as fh:
            payload = json.load(fh)
        snapshots = payload.get("snapshots", [])
        if len(snapshots) == 1 and isinstance(snapshots[0], list):
            snapshots = snapshots[0]
        for row in snapshots:
            dt = pd.to_datetime(row.get("time"), unit="s", utc=True, errors="coerce")
            if pd.isna(dt) or not (START <= dt <= END + pd.Timedelta(days=1)):
                continue
            price, method = construct_row_price(row)
            rec = {"world": world, "timestamp": dt, "date": dt.floor("D")}
            for col in [
                "buy_offer",
                "sell_offer",
                "day_average_sell",
                "day_average_buy",
                "day_sold",
                "day_bought",
                "day_highest_sell",
                "day_lowest_sell",
                "day_highest_buy",
                "day_lowest_buy",
                "buy_offers",
                "sell_offers",
                "active_traders",
            ]:
                rec[col] = num(row.get(col))
            rec["raw_price"] = price
            rec["price_method"] = method
            records.append(rec)
    raw = pd.DataFrame(records).sort_values(["world", "date", "timestamp"])

    # Keep the final price-bearing observation per UTC day. If none is price-bearing,
    # keep the final observation so missingness remains explicit.
    chosen = []
    for _, grp in raw.groupby(["world", "date"], sort=False):
        valid = grp[grp["raw_price"].notna()]
        chosen.append((valid if not valid.empty else grp).iloc[-1])
    panel = pd.DataFrame(chosen).reset_index(drop=True)

    # Outlier scrub: centered 15-day median; 5 rolling MAD with a 12% floor.
    panel["price"] = panel["raw_price"]
    panel["outlier"] = False
    for world, idx in panel.groupby("world").groups.items():
        s = panel.loc[idx].sort_values("date").set_index("date")["raw_price"]
        med = s.rolling("15D", center=True, min_periods=5).median()
        abs_dev = (s - med).abs()
        mad = abs_dev.rolling("15D", center=True, min_periods=5).median()
        threshold = np.maximum(5.0 * mad, 0.12 * med.abs())
        bad = abs_dev > threshold
        bad_idx = panel.loc[idx].sort_values("date").index[bad.fillna(False).to_numpy()]
        panel.loc[bad_idx, "price"] = np.nan
        panel.loc[bad_idx, "outlier"] = True

    # Sell-side and buy-side high/low ranges restricted to plausible values.
    highs, lows = [], []
    for _, r in panel.iterrows():
        p = r["price"]
        vals = [
            r["day_highest_sell"],
            r["day_lowest_sell"],
            r["day_highest_buy"],
            r["day_lowest_buy"],
        ]
        good = [v for v in vals if np.isfinite(v) and np.isfinite(p) and 0.5 * p <= v <= 2 * p]
        highs.append(max(good) if good else np.nan)
        lows.append(min(good) if good else np.nan)
    panel["day_high"] = highs
    panel["day_low"] = lows

    meta_small = meta[
        [
            "name",
            "location",
            "pvp_type",
            "transfer_type",
            "battleye_cohort",
            "merge_flag",
            "launch_in_window",
            "game_world_type",
            "created",
            "snapshot_population",
            "corrected_population_estimate",
            "age_years_at_end",
        ]
    ].rename(columns={"name": "world"})
    panel = panel.merge(meta_small, on="world", how="left")
    counts = panel.groupby("world")["price"].count().rename("observations")
    panel = panel.merge(counts, on="world", how="left")
    panel["converged"] = (
        (panel["observations"] >= 200)
        & panel["game_world_type"].eq("regular")
        & ~panel["launch_in_window"]
    )
    panel = panel.sort_values(["world", "date"])
    panel["log_price"] = np.log(panel["price"])
    panel["return"] = panel.groupby("world")["log_price"].diff()
    panel["sold_log_lag"] = panel.groupby("world")["day_sold"].shift(1).pipe(np.log1p)
    panel["bought_log_lag"] = panel.groupby("world")["day_bought"].shift(1).pipe(np.log1p)
    cross = (
        panel[panel["converged"] & panel["price"].notna()]
        .groupby("date")["log_price"]
        .mean()
        .rename("cross_log_mean")
    )
    panel = panel.merge(cross, on="date", how="left")
    panel["deviation"] = panel["log_price"] - panel["cross_log_mean"]
    panel["lagged_deviation"] = panel.groupby("world")["deviation"].shift(1)
    return panel


def two_way_demean(arr, g1, g2, max_iter=100, tol=1e-12):
    z = np.asarray(arr, float).copy()
    if z.ndim == 1:
        z = z[:, None]
    df = pd.DataFrame(z)
    for _ in range(max_iter):
        old = z.copy()
        df[:] = z
        z -= df.groupby(g1, sort=False).transform("mean").to_numpy()
        df[:] = z
        z -= df.groupby(g2, sort=False).transform("mean").to_numpy()
        if np.nanmax(np.abs(z - old)) < tol:
            break
    return z


def cluster_meat(X, u, groups):
    k = X.shape[1]
    meat = np.zeros((k, k))
    codes, _ = pd.factorize(groups, sort=False)
    for code in np.unique(codes):
        mask = codes == code
        score = X[mask].T @ u[mask]
        meat += np.outer(score, score)
    return meat


def ols_clustered(X, y, g_world, g_date, names):
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    inv = np.linalg.pinv(X.T @ X)
    beta = inv @ X.T @ y
    resid = y - X @ beta
    meat = (
        cluster_meat(X, resid, g_world)
        + cluster_meat(X, resid, g_date)
        - np.einsum("ni,nj->ij", X * resid[:, None], X * resid[:, None])
    )
    cov = inv @ meat @ inv
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    z = beta / se
    p = np.array([math.erfc(abs(v) / math.sqrt(2)) for v in z])
    return pd.DataFrame({"term": names, "coefficient": beta, "std_error": se, "z": z, "p_value": p})


def panel_regressions(panel):
    cols = ["return", "lagged_deviation", "sold_log_lag", "bought_log_lag"]
    d = panel[panel["converged"]][["world", "date"] + cols].dropna().copy()
    X = d[["lagged_deviation", "sold_log_lag", "bought_log_lag"]].to_numpy()
    y = d["return"].to_numpy()

    # World FE.
    xw = X - pd.DataFrame(X).groupby(d["world"].to_numpy(), sort=False).transform("mean").to_numpy()
    yw = y - pd.Series(y).groupby(d["world"].to_numpy(), sort=False).transform("mean").to_numpy()
    r1 = ols_clustered(
        xw,
        yw,
        d["world"].to_numpy(),
        d["date"].astype(str).to_numpy(),
        ["Lagged relative-price deviation", "Lagged log sell-side quantity", "Lagged log buy-side quantity"],
    )
    r1["model"] = "World FE; two-way clustered"

    # World + date FE.
    xd = two_way_demean(X, d["world"].to_numpy(), d["date"].astype(str).to_numpy())
    yd = two_way_demean(y, d["world"].to_numpy(), d["date"].astype(str).to_numpy()).ravel()
    r2 = ols_clustered(
        xd,
        yd,
        d["world"].to_numpy(),
        d["date"].astype(str).to_numpy(),
        ["Lagged relative-price deviation", "Lagged log sell-side quantity", "Lagged log buy-side quantity"],
    )
    r2["model"] = "World + date FE; two-way clustered"
    out = pd.concat([r1, r2], ignore_index=True)
    out.to_csv(DATA / "panel_regressions_two_way_clustered.csv", index=False)
    return out


def hc1_ols(X, y, names):
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    inv = np.linalg.pinv(X.T @ X)
    beta = inv @ X.T @ y
    u = y - X @ beta
    n, k = X.shape
    meat = np.einsum("ni,nj,n->ij", X, X, u * u) * n / max(n - k, 1)
    cov = inv @ meat @ inv
    se = np.sqrt(np.maximum(np.diag(cov), 0))
    z = beta / se
    p = np.array([math.erfc(abs(v) / math.sqrt(2)) for v in z])
    return pd.DataFrame({"term": names, "coefficient": beta, "std_error": se, "z": z, "p_value": p})


def cross_section_regression(summary, meta):
    d = summary.copy()
    d = d[d["converged"] & d["current_price"].notna()].copy()
    d["optional"] = d["pvp_type"].eq("Optional PvP").astype(int)
    d["retro"] = d["pvp_type"].str.contains("Retro", na=False).astype(int)
    d["be_release"] = d["battleye_cohort"].eq("Protected since release").astype(int)
    d["sa"] = d["location"].eq("South America").astype(int)
    d["eu"] = d["location"].eq("Europe").astype(int)
    d["oc"] = d["location"].eq("Oceania").astype(int)
    cols = ["optional", "retro", "be_release", "age_years_at_end", "corrected_population_estimate", "sa", "eu", "oc"]
    d = d.dropna(subset=cols + ["current_price"])
    X = np.column_stack(
        [
            np.ones(len(d)),
            d["optional"],
            d["retro"],
            d["be_release"],
            d["age_years_at_end"],
            np.log(d["corrected_population_estimate"].clip(lower=1)),
            d["sa"],
            d["eu"],
            d["oc"],
        ]
    )
    names = ["Intercept", "Optional PvP", "Retro PvP", "BattlEye since release cohort", "World age (years)", "Log corrected population", "South America", "Europe", "Oceania"]
    out = hc1_ols(X, np.log(d["current_price"]), names)
    out["n"] = len(d)
    out.to_csv(DATA / "cross_section_corrected_population.csv", index=False)
    return out


def arbitrage_tables(panel):
    d = panel[panel["converged"] & panel["deviation"].notna()].copy()
    d["next_dev"] = d.groupby("world")["deviation"].shift(-1)
    d["gap_abs"] = d["deviation"].abs()
    d["restoring_move"] = -np.sign(d["deviation"]) * (d["next_dev"] - d["deviation"])
    d = d.dropna(subset=["next_dev"])
    bins = [-np.inf, 0.02, 0.04, 0.06, 0.10, np.inf]
    labels = ["0-2%", "2-4%", "4-6%", "6-10%", ">10%"]
    d["gap_band"] = pd.cut(d["gap_abs"], bins=bins, labels=labels, right=False)
    pooled = d.groupby("gap_band", observed=True)["restoring_move"].agg(["mean", "count"]).reset_index()
    pooled["mean_pct"] = pooled["mean"] * 100
    pooled["sample"] = "Pooled updated panel"

    cut1 = START + (END - START) / 3
    cut2 = START + 2 * (END - START) / 3
    d["era"] = np.select(
        [d["date"] < cut1, d["date"] < cut2],
        ["Early", "Middle"],
        default="Late",
    )
    subs = (
        d.groupby(["era", "gap_band"], observed=True)["restoring_move"]
        .agg(["mean", "count"])
        .reset_index()
    )
    subs["mean_pct"] = subs["mean"] * 100
    subs.to_csv(DATA / "arbitrage_threshold_subsamples.csv", index=False)
    pooled.to_csv(DATA / "arbitrage_band_updated.csv", index=False)
    return pooled, subs


def indicators(prices):
    s = prices.dropna().astype(float)
    if s.empty:
        return {}
    ret = np.log(s).diff()
    delta = s.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    rsi = 100 - 100 / (1 + rs)
    ema12 = s.ewm(span=12, adjust=False).mean()
    ema26 = s.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    return {
        "current_price": s.iloc[-1],
        "first_price": s.iloc[0],
        "first_date": s.index[0],
        "last_date": s.index[-1],
        "observations": int(s.count()),
        "change_30d": s.iloc[-1] / s.iloc[-min(31, len(s))] - 1 if len(s) > 1 else np.nan,
        "change_90d": s.iloc[-1] / s.iloc[-min(91, len(s))] - 1 if len(s) > 1 else np.nan,
        "change_full": s.iloc[-1] / s.iloc[0] - 1 if len(s) > 1 else np.nan,
        "ann_vol_30d": ret.tail(30).std() * math.sqrt(365),
        "ann_vol_full": ret.std() * math.sqrt(365),
        "sma20": s.tail(20).mean(),
        "sma50": s.tail(50).mean(),
        "rsi14": rsi.iloc[-1] if not rsi.empty else np.nan,
        "macd": macd.iloc[-1] if not macd.empty else np.nan,
    }


def build_world_summary(panel):
    rows = []
    for world, g in panel.groupby("world"):
        p = g.dropna(subset=["price"]).set_index("date")["price"]
        row = {"world": world, **indicators(p)}
        latest = g.dropna(subset=["price"]).iloc[-1] if not g.dropna(subset=["price"]).empty else None
        if latest is not None:
            for col in ["location", "pvp_type", "transfer_type", "battleye_cohort", "merge_flag", "launch_in_window", "converged", "snapshot_population", "corrected_population_estimate", "age_years_at_end"]:
                row[col] = latest[col]
        row["median_day_sold"] = g["day_sold"].where(g["day_sold"] > 0).median()
        row["median_day_bought"] = g["day_bought"].where(g["day_bought"] > 0).median()
        row["fallback_share"] = (g["price_method"] == "order-book-mid-fallback").mean()
        row["outliers_removed"] = int(g["outlier"].sum())
        row["current_deviation"] = latest["deviation"] if latest is not None else np.nan
        rows.append(row)
    out = pd.DataFrame(rows).sort_values("world")
    out.to_csv(DATA / "world_reference_table.csv", index=False)
    return out


def forecast_worlds(panel, meta, summary):
    rng = np.random.default_rng(20260730)
    forecasts = []
    paths_out = {}
    sa_worlds = meta.loc[meta["location"].eq("South America"), "name"].sort_values().tolist()
    for world in sa_worlds:
        g = panel[(panel["world"] == world) & panel["price"].notna()].sort_values("date")
        s = g.set_index("date")["price"]
        rets = np.log(s).diff().dropna().tail(730).clip(-0.10, 0.10)
        current = float(s.iloc[-1])
        drift = float(np.clip(rets.mean() if len(rets) else 0.0, -0.0005, 0.0005) * 0.10)
        residual_pool = (rets - rets.median()).to_numpy()
        if len(residual_pool) < 20:
            residual_pool = np.array([0.0])
        draws = rng.choice(residual_pool, size=(3000, 180), replace=True) + drift
        cum = np.cumsum(draws, axis=1)
        # Recenter each forecast horizon so the central forecast is exactly today's price.
        cum = cum - np.median(cum, axis=0)
        sim = current * np.exp(cum)
        paths_out[world] = {
            "dates": [str(x.date()) for x in pd.date_range(s.index[-1] + pd.Timedelta(days=1), periods=180, tz="UTC")],
            "median": np.median(sim, axis=0).tolist(),
            "p10": np.quantile(sim, 0.10, axis=0).tolist(),
            "p90": np.quantile(sim, 0.90, axis=0).tolist(),
            "p025": np.quantile(sim, 0.025, axis=0).tolist(),
            "p975": np.quantile(sim, 0.975, axis=0).tolist(),
        }
        for h, label in HORIZONS.items():
            vals = sim[:, h - 1]
            forecasts.append(
                {
                    "world": world,
                    "as_of": s.index[-1].date().isoformat(),
                    "horizon_days": h,
                    "horizon": label,
                    "current_price_gp_per_TC": current,
                    "median_gp_per_TC": current,
                    "p10_gp_per_TC": np.quantile(vals, 0.10),
                    "p90_gp_per_TC": np.quantile(vals, 0.90),
                    "p025_gp_per_TC": np.quantile(vals, 0.025),
                    "p975_gp_per_TC": np.quantile(vals, 0.975),
                    "shrunk_capped_daily_drift": drift,
                    "return_history_days": len(rets),
                }
            )
    out = pd.DataFrame(forecasts)
    out.to_csv(DATA / "south_america_forecasts.csv", index=False)
    with open(DATA / "south_america_forecast_paths.json", "w", encoding="utf-8") as fh:
        json.dump(paths_out, fh)
    return out


def forecast_backtest(panel, meta):
    rows = []
    for world in meta.loc[meta["location"].eq("South America"), "name"]:
        s = (
            panel[(panel["world"] == world) & panel["price"].notna()]
            .sort_values("date")
            .set_index("date")["price"]
        )
        for h, label in HORIZONS.items():
            if len(s) <= h + 30:
                continue
            actual = s.shift(-h)
            rw = s
            seasonal = s.shift(7)
            valid = actual.notna() & rw.notna()
            rw_ape = ((actual[valid] - rw[valid]).abs() / actual[valid]).tail(365)
            valid_s = actual.notna() & seasonal.notna()
            sn_ape = ((actual[valid_s] - seasonal[valid_s]).abs() / actual[valid_s]).tail(365)
            rows.append(
                {
                    "world": world,
                    "horizon": label,
                    "horizon_days": h,
                    "random_walk_MAPE": rw_ape.mean(),
                    "seasonal_naive_MAPE": sn_ape.mean(),
                    "random_walk_n": rw_ape.count(),
                    "seasonal_naive_n": sn_ape.count(),
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(DATA / "forecast_benchmarks.csv", index=False)
    return out


def aggregate_indices(panel):
    d = panel[panel["price"].notna()].copy()
    rows = []
    for label, sub in [
        ("All worlds", d),
        ("Converged worlds", d[d["converged"]]),
        ("South America", d[d["location"].eq("South America")]),
        ("Europe", d[d["location"].eq("Europe")]),
        ("North America", d[d["location"].eq("North America")]),
        ("Oceania", d[d["location"].eq("Oceania")]),
    ]:
        agg = sub.groupby("date")["price"].agg(["median", "mean", "count"]).reset_index()
        agg["series"] = label
        rows.append(agg)
    out = pd.concat(rows, ignore_index=True)
    out.to_csv(DATA / "aggregate_indices.csv", index=False)
    return out


def transfer_summary(transfers, meta):
    active = set(meta["name"])
    t = transfers.copy()
    t["former_region"] = t["former_world"].map(meta.set_index("name")["location"])
    t["current_region"] = t["current_world"].map(meta.set_index("name")["location"])
    t["cross_region"] = t["former_region"].notna() & t["current_region"].notna() & t["former_region"].ne(t["current_region"])
    world = pd.concat(
        [
            t[t["former_world"].isin(active)].groupby("former_world").size().rename("outflows"),
            t[t["current_world"].isin(active)].groupby("current_world").size().rename("inflows"),
        ],
        axis=1,
    ).fillna(0)
    world["net_inflow"] = world["inflows"] - world["outflows"]
    world.index.name = "world"
    world.reset_index().to_csv(DATA / "recent_transfer_flows_by_world.csv", index=False)
    return t, world.reset_index()


def main():
    meta, merges = parse_world_metadata()
    transfers = parse_transfers()
    panel = load_panel(meta)
    summary = build_world_summary(panel)
    # Ensure the cohort flags on metadata use observed counts.
    obs = summary.set_index("world")["observations"]
    meta["observations"] = meta["name"].map(obs)
    meta["first_observation"] = meta["name"].map(summary.set_index("world")["first_date"])
    meta["first_price"] = meta["name"].map(summary.set_index("world")["first_price"])
    meta["converged"] = (
        (meta["observations"] >= 200)
        & meta["game_world_type"].eq("regular")
        & ~meta["launch_in_window"]
    )
    meta.to_csv(DATA / "world_metadata.csv", index=False)

    regressions = panel_regressions(panel)
    cross = cross_section_regression(summary, meta)
    arb, arb_sub = arbitrage_tables(panel)
    forecasts = forecast_worlds(panel, meta, summary)
    benchmarks = forecast_backtest(panel, meta)
    aggregate = aggregate_indices(panel)
    transfers_enriched, flow = transfer_summary(transfers, meta)
    panel.to_csv(DATA / "clean_daily_panel.csv", index=False)

    latest_date = panel.loc[panel["price"].notna(), "date"].max()
    latest = panel[(panel["date"] == latest_date) & panel["price"].notna()]
    converged = panel[panel["converged"] & panel["price"].notna()]
    total_snapshots = 0
    for p in (SOURCE / "data/market/world").glob("*/*_tibia_coins.json"):
        with open(p, encoding="utf-8") as fh:
            snapshots = json.load(fh).get("snapshots", [])
        if len(snapshots) == 1 and isinstance(snapshots[0], list):
            snapshots = snapshots[0]
        total_snapshots += len(snapshots)
    result = {
        "generated_at": pd.Timestamp.now(tz="UTC").isoformat(),
        "panel_start": str(panel.loc[panel["price"].notna(), "date"].min().date()),
        "panel_end": str(latest_date.date()),
        "worlds": int(panel["world"].nunique()),
        "south_america_worlds": int(meta["location"].eq("South America").sum()),
        "raw_snapshots": int(total_snapshots),
        "daily_rows": int(len(panel)),
        "valid_price_rows": int(panel["price"].notna().sum()),
        "outliers_removed": int(panel["outlier"].sum()),
        "fallback_rows": int((panel["price_method"] == "order-book-mid-fallback").sum()),
        "launches_in_window": int(meta["launch_in_window"].sum()),
        "active_merge_destinations": int(meta["merge_flag"].sum()),
        "converged_worlds": int(meta["converged"].sum()),
        "current_cross_world_median": float(latest["price"].median()),
        "current_cross_world_mean": float(latest["price"].mean()),
        "current_cross_world_dispersion_cv": float(latest["price"].std() / latest["price"].mean()),
        "full_period_index_change": float(
            aggregate[aggregate["series"].eq("Converged worlds")].sort_values("date")["median"].iloc[-1]
            / aggregate[aggregate["series"].eq("Converged worlds")].sort_values("date")["median"].iloc[0]
            - 1
        ),
        "median_daily_return": float(converged["return"].median()),
        "annualized_volatility": float(converged["return"].std() * math.sqrt(365)),
        "recent_transfers": int(len(transfers)),
        "cross_region_transfer_share": float(transfers_enriched["cross_region"].mean()),
        "merge_register_records": int(len(merges)),
        "merge_predecessor_worlds": int(merges["predecessor_count"].sum()),
        "rating": "Neutral",
        "confidence_score": 79,
    }
    with open(DATA / "analysis_summary.json", "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2)

    print(json.dumps(result, indent=2))
    print("SA worlds:", ", ".join(meta.loc[meta["location"].eq("South America"), "name"]))
    print("Panel regressions:\n", regressions.to_string(index=False))
    print("Cross-section:\n", cross.to_string(index=False))
    print("Arbitrage:\n", arb.to_string(index=False))
    print("Forecast rows:", len(forecasts), "Benchmark rows:", len(benchmarks))


if __name__ == "__main__":
    main()
