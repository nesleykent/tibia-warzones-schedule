# Tibia Coin Market Report - Reproducibility Bundle

Report date: 30 July 2026  
Price data through: 29 July 2026  
Units: gp per TC

## Run order

1. Place a sparse checkout of `nesleykent/tibia-warzones-schedule` at
   `work/source-repo` with `data/market/world` available.
2. Save the current TibiaData `/v4/worlds` response as `work/worlds.json`.
3. Save GuildStats `/worlds`, `/servers-merge`, and `/world-transfer` pages in
   `work/` using the filenames referenced by `analyze_market.py`.
4. Run `analyze_market.py`.
5. Run `build_report.py`.

The bootstrap forecast uses the fixed random seed `20260730`.

## Core outputs

- `world_reference_table.csv`: statistics and indicators for all 93 worlds.
- `south_america_forecasts.csv`: 14, 30, 90, and 180-day forecast intervals
  for all 34 South American worlds.
- `clean_daily_panel.csv`: cleaned world-day panel.
- `world_metadata.csv`: current attributes, creation dates, lineage, and
  region-corrected population estimates.
- `world_merge_register.csv`: 77 merge events and 196 predecessor worlds.
- `recent_character_transfers.csv`: recent GuildStats transfer observations.
- `panel_regressions_two_way_clustered.csv`: fixed-effects estimates with
  world-and-date clustered standard errors.
- `cross_section_corrected_population.csv`: corrected population and world-type
  cross-section.

## Interpretation guardrails

- Tibia Coins are account-level assets and worlds are partially integrated.
- Prices are quoted as gp per TC.
- Absolute levels are modeled as non-stationary; forecast medians equal current
  prices by construction.
- Relative-price convergence is interpreted through the approximately 4%
  round-trip Market-fee band.
- Event results are associations, not causal effects.
- Merge effects are not estimable because predecessor price histories are absent.
