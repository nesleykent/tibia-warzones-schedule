#!/usr/bin/env python3
"""Build the standalone Tibia Coin quantitative report PDF."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image as PILImage
from PIL import ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.platypus.tableofcontents import TableOfContents


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
DATA = WORK / "analysis"
CHARTS = WORK / "charts"
OUT = ROOT / "outputs"
CHARTS.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
PDF_PATH = OUT / "tibia_coin_market_full_quantitative_report_2026-07-29.pdf"

with open(DATA / "analysis_summary.json", encoding="utf-8") as fh:
    S = json.load(fh)
panel = pd.read_csv(DATA / "clean_daily_panel.csv", parse_dates=["date"])
worlds = pd.read_csv(DATA / "world_reference_table.csv")
meta = pd.read_csv(DATA / "world_metadata.csv")
forecasts = pd.read_csv(DATA / "south_america_forecasts.csv")
forecast_paths = json.load(open(DATA / "south_america_forecast_paths.json", encoding="utf-8"))
benchmarks = pd.read_csv(DATA / "forecast_benchmarks.csv")
agg = pd.read_csv(DATA / "aggregate_indices.csv", parse_dates=["date"])
arb = pd.read_csv(DATA / "arbitrage_band_updated.csv")
arb_sub = pd.read_csv(DATA / "arbitrage_threshold_subsamples.csv")
panel_reg = pd.read_csv(DATA / "panel_regressions_two_way_clustered.csv")
cross_reg = pd.read_csv(DATA / "cross_section_corrected_population.csv")
transfers = pd.read_csv(DATA / "recent_character_transfers.csv")
transfer_flows = pd.read_csv(DATA / "recent_transfer_flows_by_world.csv")
merges = pd.read_csv(DATA / "world_merge_register.csv")


NAVY = "#102A43"
BLUE = "#2563A6"
GOLD = "#C69214"
ORANGE = "#D66B20"
PINK = "#B54875"
OLIVE = "#71823D"
INK = "#17212B"
MID = "#52606D"
GRID = "#D9E2EC"
PALE = "#F4F7FA"
WHITE = "#FFFFFF"
RED_DARK = "#8F3B3B"
FONT = "/System/Library/Fonts/Supplemental/Arial.ttf"
FONT_BOLD = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"


def fnt(size, bold=False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT, size=size)


def compact(v, decimals=1):
    if pd.isna(v):
        return "n/a"
    v = float(v)
    if abs(v) >= 1_000_000:
        return f"{v / 1_000_000:.{decimals}f}M"
    if abs(v) >= 1_000:
        return f"{v / 1_000:.{decimals}f}k"
    return f"{v:.{decimals}f}"


def gp(v):
    return "n/a" if pd.isna(v) else f"{float(v):,.0f} gp/TC"


def pct(v, decimals=1):
    return "n/a" if pd.isna(v) else f"{float(v) * 100:+.{decimals}f}%"


def chart_base(title, subtitle, width=1600, height=820):
    im = PILImage.new("RGB", (width, height), WHITE)
    d = ImageDraw.Draw(im)
    d.text((70, 38), title, font=fnt(40, True), fill=INK)
    d.text((70, 91), subtitle, font=fnt(23), fill=MID)
    return im, d


def nice_bounds(values):
    vals = np.asarray([v for v in values if np.isfinite(v)], float)
    if len(vals) == 0:
        return 0.0, 1.0
    lo, hi = float(vals.min()), float(vals.max())
    if lo == hi:
        return lo * 0.9, hi * 1.1
    pad = (hi - lo) * 0.10
    return lo - pad, hi + pad


def line_chart(path, title, subtitle, series, y_label, source, note, fan=None):
    im, d = chart_base(title, subtitle)
    L, T, R, B = 150, 170, 1510, 665
    all_x, all_y = [], []
    for s in series:
        all_x.extend(pd.to_datetime(s["x"]).view("int64").tolist())
        all_y.extend(np.asarray(s["y"], float).tolist())
    if fan:
        all_x.extend(pd.to_datetime(fan["x"]).view("int64").tolist())
        all_y.extend(np.asarray(fan["low2"], float).tolist())
        all_y.extend(np.asarray(fan["high2"], float).tolist())
    xmin, xmax = min(all_x), max(all_x)
    ymin, ymax = nice_bounds(all_y)

    def xy(x, y):
        xx = L + (int(pd.Timestamp(x).value) - xmin) / max(xmax - xmin, 1) * (R - L)
        yy = B - (float(y) - ymin) / max(ymax - ymin, 1e-9) * (B - T)
        return xx, yy

    for i in range(6):
        val = ymin + i * (ymax - ymin) / 5
        y = xy(pd.Timestamp(min(pd.to_datetime(series[0]["x"]))), val)[1]
        d.line((L, y, R, y), fill=GRID, width=2)
        d.text((25, y - 13), f"{val:,.0f}", font=fnt(20), fill=MID)
    d.line((L, T, L, B), fill=INK, width=3)
    d.line((L, B, R, B), fill=INK, width=3)

    dates = pd.to_datetime([pd.Timestamp(xmin), pd.Timestamp(xmax)])
    for i in range(6):
        dt = dates[0] + (dates[1] - dates[0]) * i / 5
        x = L + i * (R - L) / 5
        d.line((x, B, x, B + 8), fill=INK, width=2)
        d.text((x - 47, B + 16), dt.strftime("%b %Y"), font=fnt(18), fill=MID)
    d.text((L + (R - L) / 2 - 40, B + 59), "Date", font=fnt(21, True), fill=INK)
    d.text((25, T - 40), y_label, font=fnt(20, True), fill=INK)

    if fan:
        fx = pd.to_datetime(fan["x"])
        p2 = [xy(x, y) for x, y in zip(fx, fan["high2"])]
        p2 += [xy(x, y) for x, y in zip(fx[::-1], fan["low2"][::-1])]
        d.polygon(p2, fill="#DCE8F3")
        p1 = [xy(x, y) for x, y in zip(fx, fan["high1"])]
        p1 += [xy(x, y) for x, y in zip(fx[::-1], fan["low1"][::-1])]
        d.polygon(p1, fill="#BBD1E5")

    for s in series:
        pts = [xy(x, y) for x, y in zip(pd.to_datetime(s["x"]), s["y"]) if np.isfinite(y)]
        if len(pts) > 1:
            d.line(pts, fill=s["color"], width=s.get("width", 5))
    lx = 180
    for s in series:
        d.line((lx, 135, lx + 40, 135), fill=s["color"], width=6)
        d.text((lx + 50, 121), s["name"], font=fnt(19), fill=INK)
        lx += 50 + d.textlength(s["name"], font=fnt(19)) + 55
    if fan:
        d.rectangle((lx, 124, lx + 28, 145), fill="#BBD1E5")
        d.text((lx + 38, 121), "80% interval", font=fnt(19), fill=INK)
        lx += 170
        d.rectangle((lx, 124, lx + 28, 145), fill="#DCE8F3")
        d.text((lx + 38, 121), "95% interval", font=fnt(19), fill=INK)

    d.text((70, 740), f"Source: {source}", font=fnt(18), fill=MID)
    d.text((70, 772), f"Note: {note}", font=fnt(17), fill=MID)
    im.save(path, quality=95)


def bar_chart(path, title, subtitle, labels, values, y_label, source, note, colors_list=None, horizontal=False):
    im, d = chart_base(title, subtitle)
    if horizontal:
        L, T, R, B = 330, 165, 1510, 675
        vals = np.asarray(values, float)
        vmax = max(float(vals.max()) * 1.12, 1)
        n = len(labels)
        bar_h = max(6, (B - T) / max(n, 1) * 0.66)
        for i in range(6):
            x = L + i * (R - L) / 5
            d.line((x, T, x, B), fill=GRID, width=2)
            d.text((x - 28, B + 15), f"{vmax * i / 5:,.0f}", font=fnt(17), fill=MID)
        for i, (lab, val) in enumerate(zip(labels, vals)):
            y = T + (i + 0.5) * (B - T) / n
            x = L + val / vmax * (R - L)
            col = colors_list[i] if colors_list else BLUE
            d.rectangle((L, y - bar_h / 2, x, y + bar_h / 2), fill=col)
            d.text((20, y - 12), str(lab)[:30], font=fnt(17), fill=INK)
            d.text((x + 8, y - 11), f"{val:,.0f}", font=fnt(16, True), fill=INK)
        d.text((L + 390, B + 57), y_label, font=fnt(20, True), fill=INK)
    else:
        L, T, R, B = 150, 170, 1510, 665
        vals = np.asarray(values, float)
        lo = min(0.0, float(vals.min()) * 1.2)
        hi = max(0.0, float(vals.max()) * 1.2)
        for i in range(6):
            val = lo + i * (hi - lo) / 5
            y = B - (val - lo) / max(hi - lo, 1e-9) * (B - T)
            d.line((L, y, R, y), fill=GRID, width=2)
            d.text((35, y - 12), f"{val:,.2f}", font=fnt(18), fill=MID)
        zero_y = B - (0 - lo) / max(hi - lo, 1e-9) * (B - T)
        d.line((L, zero_y, R, zero_y), fill=INK, width=3)
        slot = (R - L) / max(len(labels), 1)
        for i, (lab, val) in enumerate(zip(labels, vals)):
            x0 = L + i * slot + slot * 0.18
            x1 = L + (i + 1) * slot - slot * 0.18
            yv = B - (val - lo) / max(hi - lo, 1e-9) * (B - T)
            col = colors_list[i] if colors_list else BLUE
            d.rectangle((x0, min(zero_y, yv), x1, max(zero_y, yv)), fill=col)
            d.text((x0, B + 15), str(lab), font=fnt(17), fill=INK)
            d.text((x0, min(zero_y, yv) - 26), f"{val:,.2f}", font=fnt(16, True), fill=INK)
        d.text((25, T - 40), y_label, font=fnt(20, True), fill=INK)
    d.text((70, 740), f"Source: {source}", font=fnt(18), fill=MID)
    d.text((70, 772), f"Note: {note}", font=fnt(17), fill=MID)
    im.save(path, quality=95)


def create_charts():
    # Aggregate regional indices.
    series = []
    palette = {"South America": BLUE, "Europe": GOLD, "North America": ORANGE, "Oceania": OLIVE}
    for name in palette:
        d = agg[agg["series"].eq(name)].sort_values("date").set_index("date")["median"].resample("14D").median().dropna()
        series.append({"name": name, "x": d.index, "y": d.values, "color": palette[name]})
    line_chart(
        CHARTS / "regional_indices.png",
        "Median Tibia Coin price by world region",
        "gp per TC; 14-day medians; 11 Jan 2023 to 29 Jul 2026",
        series,
        "gp per TC",
        "GitHub price archive; TibiaData world metadata",
        "Worlds are partially integrated. Launch-phase worlds are included in regional medians; missing prices are not interpolated.",
    )

    # Event associations from verified evidence.
    bar_chart(
        CHARTS / "event_associations.png",
        "Average daily return association on scheduled event days",
        "Percentage points versus non-event days; converged worlds",
        ["XP/Skill", "Rapid Respawn", "14d pre-update"],
        [-0.28, -0.21, 0.06],
        "Difference in daily return (pp)",
        "Verified event calendar; GitHub price archive",
        "World fixed effects only. Global scheduling is collinear with date fixed effects; associations are not causal.",
        [PINK, ORANGE, BLUE],
    )

    # Arbitrage response from verified evidence.
    bar_chart(
        CHARTS / "arbitrage_band.png",
        "Next-day restoring movement by relative-price gap",
        "Percentage points per day; lagged deviation from the cross-world mean",
        ["0-2%", "2-4%", "4-6%", "6-10%", ">10%"],
        [-0.053, -0.005, 0.016, 0.065, 0.138],
        "Restoring movement (pp/day)",
        "Verified pooled panel result; GitHub price archive",
        "Positive values close the cross-world gap. The approximately 4% threshold was estimated from prices, not imposed.",
        [PINK, PINK, BLUE, BLUE, BLUE],
    )

    # Population correction factors.
    bar_chart(
        CHARTS / "population_factors.png",
        "Correction factor for the 04:45 UTC population snapshot",
        "Past-year daily-average online divided by the instantaneous snapshot",
        ["Europe", "South America", "Oceania", "North America"],
        [2.47, 1.57, 1.07, 0.80],
        "Multiplicative factor",
        "GuildStats past-year averages; TibiaData 04:45 UTC snapshot; 15-world validation sample",
        "Factors are region-level estimates, not world-specific population histories.",
        [BLUE, GOLD, OLIVE, ORANGE],
    )

    # Current price by PvP type.
    pvp = worlds[worlds["converged"] == True].groupby("pvp_type")["current_price"].median().sort_values()
    bar_chart(
        CHARTS / "pvp_prices.png",
        "Current median price by PvP type",
        "Converged worlds only; each world's latest observation through 29 Jul 2026",
        list(pvp.index),
        list(pvp.values),
        "gp per TC",
        "GitHub price archive; TibiaData world metadata; GuildStats creation and merge records",
        "Unadjusted medians are descriptive. The adjusted Optional PvP coefficient is reported in the econometric section.",
        horizontal=True,
    )

    # First price by provenance.
    merged = meta.copy()
    cats = ["Genuine launches", "Merge destinations", "Mature/other"]
    vals = [
        merged.loc[merged["launch_in_window"] == True, "first_price"].median(),
        merged.loc[(merged["merge_flag"] == True) & merged["created_utc"].str[:10].ge("2023-01-11"), "first_price"].median(),
        merged.loc[(merged["launch_in_window"] != True) & (merged["merge_flag"] != True), "first_price"].median(),
    ]
    bar_chart(
        CHARTS / "provenance_first_price.png",
        "First observed price by world provenance",
        "Median first valid archive price; gp per TC",
        cats,
        vals,
        "gp per TC",
        "GitHub price archive; GuildStats creation dates and merge register",
        "Provenance uses documented creation and merge status; dataset entry date alone does not identify a launch.",
        horizontal=True,
    )

    # Transfer flows.
    tf = transfer_flows.sort_values("net_inflow").tail(12)
    bar_chart(
        CHARTS / "transfer_net_flows.png",
        "Recent observed net character-transfer flows",
        "Tracked transfers on the GuildStats default seven-day view",
        tf["world"].tolist(),
        tf["net_inflow"].tolist(),
        "Net observed transfers",
        "GuildStats world-transfer, collected 30 Jul 2026",
        "The page is a recent observed list, not a complete historical census; same-world records are retained in the source table.",
        horizontal=True,
    )

    # South America current prices.
    sa = worlds[worlds["location"].eq("South America")].sort_values("current_price")
    bar_chart(
        CHARTS / "sa_current_prices.png",
        "Latest Tibia Coin price across South American worlds",
        "gp per TC; latest valid observation through 29 Jul 2026",
        sa["world"].tolist(),
        sa["current_price"].tolist(),
        "gp per TC",
        "GitHub price archive; TibiaData region classification",
        "Worlds are ordered by price. Launch-phase and merge-destination worlds are shown but not pooled with converged worlds in inference.",
        horizontal=True,
    )

    # Six-month interval width.
    fw = forecasts[forecasts["horizon_days"].eq(180)].copy()
    fw["width_pct"] = (fw["p975_gp_per_TC"] - fw["p025_gp_per_TC"]) / fw["current_price_gp_per_TC"] * 100
    fw = fw.sort_values("width_pct")
    bar_chart(
        CHARTS / "forecast_widths.png",
        "Six-month forecast uncertainty by South American world",
        "Width of the bootstrapped 95% prediction interval as percent of current price",
        fw["world"].tolist(),
        fw["width_pct"].tolist(),
        "95% interval width (% of price)",
        "Cleaned GitHub price archive; bootstrap random-walk model",
        "Median forecasts equal current prices by construction. Wider intervals reflect greater historical return dispersion.",
        horizontal=True,
    )

    # Example forecast.
    w = "Belobra"
    g = panel[(panel["world"].eq(w)) & panel["price"].notna()].sort_values("date").tail(365)
    fp = forecast_paths[w]
    fdates = pd.to_datetime(fp["dates"])
    line_chart(
        CHARTS / "forecast_example.png",
        f"{w}: historical price and random-walk forecast",
        "gp per TC; latest 12 months plus 180-day forecast",
        [
            {"name": "Observed price", "x": g["date"], "y": g["price"], "color": NAVY},
            {"name": "Forecast median", "x": fdates, "y": fp["median"], "color": BLUE},
        ],
        "gp per TC",
        "GitHub price archive; bootstrap random-walk model",
        "The fan uses 80% and 95% prediction intervals. The median is the current price by construction; no level mean reversion is imposed.",
        fan={"x": fdates, "low1": np.array(fp["p10"]), "high1": np.array(fp["p90"]), "low2": np.array(fp["p025"]), "high2": np.array(fp["p975"])},
    )

    # Individual South American charts.
    for world in sorted(forecast_paths):
        g = panel[(panel["world"].eq(world)) & panel["price"].notna()].sort_values("date").tail(540)
        fp = forecast_paths[world]
        fdates = pd.to_datetime(fp["dates"])
        line_chart(
            CHARTS / f"sa_{world.lower()}.png",
            f"{world}: price history and forecast distribution",
            "gp per TC; latest 18 months plus 180-day forecast",
            [
                {"name": "Observed price", "x": g["date"], "y": g["price"], "color": NAVY},
                {"name": "Forecast median", "x": fdates, "y": fp["median"], "color": BLUE},
            ],
            "gp per TC",
            "GitHub price archive; TibiaData region; bootstrap random-walk model",
            "Valid cleaned daily observations only. Forecast median equals current price; fan shows 80% and 95% prediction intervals.",
            fan={"x": fdates, "low1": np.array(fp["p10"]), "high1": np.array(fp["p90"]), "low2": np.array(fp["p025"]), "high2": np.array(fp["p975"])},
        )


pdfmetrics.registerFont(TTFont("Arial", FONT))
pdfmetrics.registerFont(TTFont("Arial-Bold", FONT_BOLD))


class ReportDoc(BaseDocTemplate):
    def __init__(self, filename):
        super().__init__(
            filename,
            pagesize=A4,
            rightMargin=17 * mm,
            leftMargin=17 * mm,
            topMargin=18 * mm,
            bottomMargin=17 * mm,
            title="Tibia Coin Market - Full Quantitative Report",
            author="Quantitative Market Analysis",
            subject="Gold-denominated Tibia Coin market across 93 worlds",
        )
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="body")
        self.addPageTemplates(PageTemplate(id="main", frames=[frame], onPage=self.draw_page))

    def draw_page(self, canvas, doc):
        canvas.saveState()
        page = canvas.getPageNumber()
        if page > 1:
            canvas.setStrokeColor(colors.HexColor(GRID))
            canvas.line(17 * mm, A4[1] - 13 * mm, A4[0] - 17 * mm, A4[1] - 13 * mm)
            canvas.setFont("Arial", 7.5)
            canvas.setFillColor(colors.HexColor(MID))
            canvas.drawString(17 * mm, A4[1] - 10 * mm, "Tibia Coin Market - Full Quantitative Report")
            canvas.drawRightString(A4[0] - 17 * mm, 9 * mm, f"Page {page}")
            canvas.drawString(17 * mm, 9 * mm, "Data through 29 Jul 2026 | Prices in gp per TC")
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph):
            style = flowable.style.name
            if style in ("H1", "AppendixH1"):
                level = 0
            elif style == "H2":
                level = 1
            else:
                return
            text = flowable.getPlainText()
            key = "h%d-%s" % (level, abs(hash((text, self.page))) % 10**10)
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text, key, level=level, closed=False)
            self.notify("TOCEntry", (level, text, self.page, key))


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="CoverTitle", fontName="Arial-Bold", fontSize=29, leading=34, textColor=colors.HexColor(NAVY), alignment=TA_LEFT, spaceAfter=10))
styles.add(ParagraphStyle(name="CoverSub", fontName="Arial", fontSize=14, leading=20, textColor=colors.HexColor(MID), spaceAfter=9))
styles.add(ParagraphStyle(name="H1", fontName="Arial-Bold", fontSize=18, leading=23, textColor=colors.HexColor(NAVY), spaceBefore=4, spaceAfter=10, keepWithNext=True))
styles.add(ParagraphStyle(name="AppendixH1", parent=styles["H1"], fontSize=19))
styles.add(ParagraphStyle(name="H2", fontName="Arial-Bold", fontSize=12.5, leading=16, textColor=colors.HexColor(BLUE), spaceBefore=10, spaceAfter=6, keepWithNext=True))
styles.add(ParagraphStyle(name="Body", fontName="Arial", fontSize=9.2, leading=13.2, textColor=colors.HexColor(INK), spaceAfter=7))
styles.add(ParagraphStyle(name="Small", fontName="Arial", fontSize=7.3, leading=10, textColor=colors.HexColor(MID), spaceAfter=4))
styles.add(ParagraphStyle(name="Callout", fontName="Arial", fontSize=10, leading=14, textColor=colors.HexColor(INK), backColor=colors.HexColor(PALE), borderColor=colors.HexColor(GRID), borderWidth=0.7, borderPadding=8, spaceBefore=6, spaceAfter=10))
styles.add(ParagraphStyle(name="TableCell", fontName="Arial", fontSize=6.5, leading=8.2, textColor=colors.HexColor(INK)))
styles.add(ParagraphStyle(name="TableHead", fontName="Arial-Bold", fontSize=6.5, leading=8.2, textColor=colors.white))
styles.add(ParagraphStyle(name="WorldTitle", fontName="Arial-Bold", fontSize=16, leading=20, textColor=colors.HexColor(NAVY), spaceAfter=6))
styles.add(ParagraphStyle(name="TOCHead", fontName="Arial-Bold", fontSize=20, leading=24, textColor=colors.HexColor(NAVY), spaceAfter=12))


def P(text, style="Body"):
    return Paragraph(text, styles[style])


def claim(label, text, style="Body"):
    return P(f"<b>{label}.</b> {text}", style)


def H1(n, title):
    return P(f"{n}  {title}", "H1")


def H2(title):
    return P(title, "H2")


def safe_table(rows, widths=None, repeatRows=1, font_size=None, aligns=None):
    converted = []
    for ri, row in enumerate(rows):
        style = styles["TableHead"] if ri == 0 else styles["TableCell"]
        converted.append([c if hasattr(c, "wrap") else Paragraph(str(c), style) for c in row])
    t = Table(converted, colWidths=widths, repeatRows=repeatRows, hAlign="LEFT")
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(NAVY)),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor(GRID)),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for i in range(1, len(rows)):
        if i % 2 == 0:
            commands.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor(PALE)))
    if aligns:
        for col, align in enumerate(aligns):
            commands.append(("ALIGN", (col, 1), (col, -1), align))
    t.setStyle(TableStyle(commands))
    return t


def fig(path, width=176 * mm):
    with PILImage.open(path) as im:
        ratio = im.height / im.width
    return Image(str(path), width=width, height=width * ratio)


def section_break():
    return PageBreak()


def add_table_caption(story, title, note):
    story.append(P(f"<b>{title}</b>", "Small"))
    story.append(P(note, "Small"))


def build_story():
    story = []
    # Cover
    story += [
        Spacer(1, 28 * mm),
        P("Tibia Coin Market", "CoverTitle"),
        P("Full Quantitative Report", "CoverTitle"),
        Spacer(1, 5 * mm),
        P("Gold-denominated prices across 93 game worlds", "CoverSub"),
        P("Observation window: 11 January 2023 to 29 July 2026", "CoverSub"),
        Spacer(1, 20 * mm),
        P("<b>Overall rating</b>", "CoverSub"),
        P("Neutral", "CoverTitle"),
        P("Confidence score: 79 / 100", "CoverSub"),
        Spacer(1, 20 * mm),
        claim("Observed data", f"The cleaned panel contains {S['valid_price_rows']:,} valid daily price observations across {S['worlds']} worlds, including {S['south_america_worlds']} South American worlds.", "Callout"),
        claim("Analyst judgement", "The common gp price level is not statistically mean-reverting, while relative world prices are. This supports a Neutral level outlook and an active relative-value framework.", "Callout"),
        Spacer(1, 24 * mm),
        P("Prepared 30 July 2026 | Prices are quoted as gp per TC", "Small"),
        PageBreak(),
    ]

    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle(name="TOC0", fontName="Arial", fontSize=8.5, leading=11, leftIndent=0, firstLineIndent=0, textColor=colors.HexColor(INK), spaceBefore=2),
        ParagraphStyle(name="TOC1", fontName="Arial", fontSize=7.5, leading=9.5, leftIndent=12, firstLineIndent=0, textColor=colors.HexColor(MID)),
    ]
    story += [P("Contents", "TOCHead"), toc, PageBreak()]

    # 1
    story.append(H1(1, "Executive Summary"))
    story.append(claim("Analyst judgement", "<b>Overall rating: Neutral, with 79/100 confidence.</b> The level forecast is deliberately non-directional because every world price series is non-stationary and no defensible gp-supply or TC-supply anchor is observed. Relative mispricing across worlds is more predictable than the shared level."))
    story.append(claim("Observed data", f"The converged-world median rose {pct(S['full_period_index_change'])} over the sample. Across each world's latest observation, the converged cohort has a median of {gp(worlds.loc[worlds['converged'] == True, 'current_price'].median())} and a cross-sectional coefficient of variation of {worlds.loc[worlds['converged'] == True, 'current_price'].std() / worlds.loc[worlds['converged'] == True, 'current_price'].mean() * 100:.1f}%."))
    story.append(claim("Statistical relationship", "Relative-price deviations show a transaction-cost band: gaps below about 4% have no meaningful restoring force, while larger gaps close progressively faster. The threshold matches the approximately 4% round-trip Market fee and was recovered from price behavior."))
    story.append(claim("Statistical relationship", "The corrected cross-section estimates an Optional PvP coefficient of +5.6% and a BattlEye-since-release cohort coefficient of -4.5%. The corrected population term remains statistically insignificant, but measurement error and residual cross-world dependence prevent interpreting that as evidence of no population effect."))
    story.append(claim("Forecast", "For all 34 South American worlds, the median at two weeks, one month, three months, and six months equals the current price by construction. The decision-useful output is interval width: the median six-month 95% interval spans about " + f"{((forecasts.loc[forecasts.horizon_days == 180, 'p975_gp_per_TC'] - forecasts.loc[forecasts.horizon_days == 180, 'p025_gp_per_TC']) / forecasts.loc[forecasts.horizon_days == 180, 'current_price_gp_per_TC']).median() * 100:.0f}% of current price."))
    story.append(claim("Economic interpretation", "Tibia Coins are account-level assets that can be bought with gp on one world and sold on another without a Character World Transfer. The market is therefore a set of partially integrated local markets, not independent world economies."))
    story.append(fig(CHARTS / "regional_indices.png"))

    # 2
    story += [section_break(), H1(2, "Scope and Research Questions")]
    story.append(claim("Observed data", "The scope is the gold-denominated Tibia Coin market for the 93 worlds represented in the archive from 11 January 2023 through 29 July 2026. Prices are expressed exclusively as gp per TC."))
    story.append(claim("Analyst judgement", "The report addresses five decisions: whether the shared price level has a defensible directional forecast; how quickly relative mispricing closes; whether world structure, population, events, liquidity, launch provenance, and transfers explain differences; how uncertain South American world forecasts are; and which risks invalidate naive trading signals."))
    story.append(claim("Observed data", "Inference separates 61 converged regular worlds from 29 genuine launches that began inside the observation window. Launch-phase worlds are shown descriptively but are not pooled into converged-world cross-sectional estimates."))
    story.append(claim("Forecast", "Forecast horizons are 14, 30, 90, and 180 days. Prediction intervals are model distributions, not analyst price targets."))

    # 3
    story += [section_break(), H1(3, "Game-Economy Context")]
    story.append(claim("Documented mechanic", "Tibia Coins are account-level assets. A player with characters on two worlds can buy TC with gp on one world and sell TC for gp on another; a Character World Transfer is not required."))
    story.append(claim("Documented mechanic", "Each Market offer costs 2% of its value, subject to a minimum of 20 gp and a maximum of 250,000 gp. The fee is charged when the offer is created and is not refunded on cancellation. A buy-then-sell cross-world cycle therefore faces approximately 4% in round-trip offer fees before execution risk."))
    story.append(claim("Economic interpretation", "The account-level mobility of TC integrates world prices, while local gp balances, player composition, offer depth, and transfer restrictions preserve temporary differences. The appropriate model is partial integration with a transaction-cost band."))
    story.append(claim("Hypothesis", "Long-run price appreciation may reflect gp accumulation, changing TC demand, or both. No accessible series measures gp stock, gp income, or TC supply, so gp inflation remains an unmeasured hypothesis."))

    # 4
    story += [section_break(), H1(4, "Data Sources and Provenance")]
    rows = [
        ["Source", "Role", "Coverage", "Provenance"],
        ["GitHub archive", "Historical MarketValues snapshots for item 22118", "93 worlds; 11 Jan 2023 to 29 Jul 2026", "Deduplicated third-party mirror with TibiaMarket.top schema"],
        ["TibiaMarket.top", "Schema, events, live order book, metadata", "History from 11 Jan 2023; current book", "Third-party API; no authentication observed"],
        ["TibiaData v4", "Current world attributes and population snapshot", "Current snapshot", "Supported fansite sourcing tibia.com"],
        ["GuildStats.eu", "Creation dates, merges, recent transfers, population history", "77 merges; 196 predecessors; current pages", "Third-party fansite; robots.txt permits these pages"],
        ["Official Tibia news", "Update release dates and documented mechanics", "Release-specific", "Primary source"],
    ]
    story.append(safe_table(rows, [30 * mm, 48 * mm, 44 * mm, 54 * mm]))
    story.append(claim("Observed data", "The archive schema is byte-identical to the TibiaMarket.top MarketValues model. It is not an official CipSoft feed and is described throughout as a third-party mirror."))
    story.append(claim("Documented mechanic", "TibiaVIP population endpoints are excluded because robots.txt disallows the relevant paths."))

    # 5
    story += [section_break(), H1(5, "Data Inventory")]
    inv = [
        ["Asset", "Rows / units", "Date range", "Use"],
        ["Raw price snapshots", f"{S['raw_snapshots']:,}", "11 Jan 2023 - 29 Jul 2026", "Source observations before daily selection"],
        ["Clean daily panel", f"{S['daily_rows']:,}", "11 Jan 2023 - 29 Jul 2026", "Panel analysis and charts"],
        ["Valid daily prices", f"{S['valid_price_rows']:,}", "11 Jan 2023 - 29 Jul 2026", "Observed-price statistics"],
        ["World metadata", "93 worlds", "Current attributes plus creation/merge history", "Cohorts and controls"],
        ["Merge register", "77 destinations / 196 predecessors", "2014 - 2025", "Lineage classification"],
        ["Recent transfers", f"{S['recent_transfers']}", "GuildStats default seven-day view", "Exploratory linkage channel"],
        ["South American forecasts", "136 horizon-world rows", "As of each latest price", "14/30/90/180-day distributions"],
    ]
    story.append(safe_table(inv, [38 * mm, 35 * mm, 48 * mm, 55 * mm]))
    story.append(claim("Observed data", f"Daily selection and validation produce {S['valid_price_rows']:,} usable price rows. The panel contains {S['outliers_removed']} removed outliers and {S['fallback_rows']} order-book-mid fallback rows."))

    # 6
    story += [section_break(), H1(6, "Data Validation and Cleaning")]
    cleaning = [
        ["Step", "Rule", "Purpose"],
        ["Sentinels", "Replace -1 with missing before arithmetic", "Prevents failed scans from becoming prices or quantities"],
        ["Executed averages", "Accept a side only when its quantity is positive and average exceeds 1,000 gp", "Excludes zero-trade and invalid days"],
        ["Daily price", "Mean of valid buy-side and sell-side executed averages", "Symmetric transaction-price proxy"],
        ["Fallback", "Order-book mid only when 0.5 <= ask/bid <= 2.0", "Uses plausible current quotes when executed averages are absent"],
        ["Outliers", "Centered 15-day median; 5 rolling MAD; minimum threshold 12%", "Retains genuine large market moves"],
        ["Range", "Four daily high/low fields, restricted to 0.5x-2.0x price", "Avoids placeholder lows and invalid extremes"],
        ["Time", "Unix time to UTC, floored to day", "Consistent panel key"],
    ]
    story.append(safe_table(cleaning, [30 * mm, 92 * mm, 54 * mm]))
    story.append(claim("Observed data", "Price-measure sensitivity is small: the quantity-weighted measure differs from the simple side mean by 0.49%, order-book mid by 0.89%, and sell-side-only by 2.28% in the verified sensitivity test."))
    story.append(claim("Analyst judgement", "The cleaning design prioritizes semantic validity over mechanical completeness. Statistics use observed days; single-day interpolation is reserved for display indicators."))

    # 7
    story += [section_break(), H1(7, "Field Definitions")]
    fields = [
        ["Field", "Definition", "Permitted interpretation"],
        ["buy_offer / sell_offer", "Current best displayed order prices", "Order-book bid and ask, subject to snapshot timing"],
        ["buy_offers / sell_offers", "Counts of standing orders", "Order counts only; not depth, demand, or participants"],
        ["day_average_sell / buy", "Average executed price on each side", "Transaction averages; their gap is not the quoted spread"],
        ["day_sold / day_bought", "Executed TC quantities on each side", "Report separately; their sum may double count trades"],
        ["active_traders", "Undocumented activity field", "TC-market participation proxy only"],
        ["market_board.amount", "TC quantity in an offer", "True displayed offer depth"],
        ["market_board.time", "Unresolved timestamp semantics", "Likely expiry, not creation"],
    ]
    story.append(safe_table(fields, [38 * mm, 66 * mm, 72 * mm]))
    story.append(claim("Observed data", "Antica's live book showed four sell orders and 37 buy orders, including 11 buy orders below 2,000 gp against a market near 39,300 gp. Order-count ratios are therefore contaminated by non-executable placeholders."))

    # 8
    story += [section_break(), H1(8, "Price Construction")]
    story.append(claim("Observed data", "The primary price is the arithmetic mean of the valid sell-side and buy-side daily executed averages. This is a simple transaction-side mean; it is not described as a VWAP, midpoint, or quoted spread."))
    story.append(claim("Observed data", "When only one executed side is valid, that side is used. When neither side is valid, a plausible order-book mid is allowed under the ask/bid ratio screen. Failed scans and zero-trade values remain missing."))
    story.append(claim("Observed data", "On 818 overlapping Antica days, transaction mid divided by order-book mid averaged 0.9964 with a standard deviation of 1.27%. This validates the fallback as a close proxy in the tested overlap."))
    story.append(claim("Limitation", "The UTC day boundary approximates the Tibia economic day, which begins at server save. Events or trades spanning server save may be assigned to adjacent UTC dates."))

    # 9
    story += [section_break(), H1(9, "World Metadata")]
    story.append(claim("Observed data", f"The metadata joins all {S['worlds']} worlds to region, PvP type, BattlEye cohort, transfer policy, creation date, merge lineage, first observation, and first price."))
    story.append(claim("Observed data", f"Creation dates and the merge register classify {S['launches_in_window']} genuine launches inside the observation window. The 93 active worlds include {S['active_merge_destinations']} destinations that appear anywhere in the historical merge register; 20 merge destinations were created inside the price observation window."))
    story.append(claim("Statistical relationship", "World provenance explains first-price behavior more reliably than nominal age. New merge destinations inherit mature local balances and open near mature prices, while genuine launches begin near much lower gp-per-TC levels."))
    story.append(fig(CHARTS / "provenance_first_price.png"))

    # 10
    story += [section_break(), H1(10, "Population and Activity")]
    story.append(claim("Observed data", "The TibiaData population value is a single 04:45 UTC snapshot. Against 15 GuildStats past-year daily averages, the regional correction factors are 2.47x for Europe, 1.57x for South America, 1.07x for Oceania, and 0.80x for North America."))
    story.append(fig(CHARTS / "population_factors.png"))
    pop_row = cross_reg[cross_reg["term"].eq("Log corrected population")].iloc[0]
    story.append(claim("Statistical relationship", f"After applying regional factors to all 93 snapshots, the converged-world cross-section estimates a log-population coefficient of {pop_row.coefficient:+.3f} (robust p={pop_row.p_value:.3f}; n={int(pop_row.n)}). The estimate is not statistically distinguishable from zero."))
    story.append(claim("Analyst judgement", "The null does not establish that population is irrelevant. Region-level factors are estimated from a 15-world validation sample and leave world-specific measurement error that can attenuate the coefficient."))

    # 11
    story += [section_break(), H1(11, "Event Calendar")]
    ev = [
        ["Indicator", "Count / window", "Definition"],
        ["XP/Skill event", "108 flagged days", "Global scheduled event dates"],
        ["Rapid Respawn", "55 flagged days", "Global scheduled event dates"],
        ["Update releases", "7 releases", "Official Tibia news dates"],
        ["Pre-update window", "14 days", "Days before each release"],
        ["Post-update window", "30 days", "Days after each release"],
    ]
    story.append(safe_table(ev, [48 * mm, 38 * mm, 90 * mm]))
    story.append(claim("Observed data", "TibiaMarket.top events have no world dimension and omit update releases. Global event labels come from the events endpoint; release dates come from official Tibia news."))
    story.append(claim("Statistical relationship", "Because events are global, their main effects are perfectly collinear with date fixed effects. A world-fixed-effects-only model identifies event-date differences but cannot separate the event from any other same-day global factor."))

    # 12
    story += [section_break(), H1(12, "Descriptive Statistics")]
    conv = worlds[worlds["converged"] == True]
    desc = [
        ["Metric", "All 93 worlds", "61 converged worlds", "South America"],
        ["Latest-price median", gp(worlds.current_price.median()), gp(conv.current_price.median()), gp(worlds.loc[worlds.location.eq("South America"), "current_price"].median())],
        ["Latest-price mean", gp(worlds.current_price.mean()), gp(conv.current_price.mean()), gp(worlds.loc[worlds.location.eq("South America"), "current_price"].mean())],
        ["Cross-sectional CV", f"{worlds.current_price.std()/worlds.current_price.mean()*100:.1f}%", f"{conv.current_price.std()/conv.current_price.mean()*100:.1f}%", f"{worlds.loc[worlds.location.eq('South America'), 'current_price'].std()/worlds.loc[worlds.location.eq('South America'), 'current_price'].mean()*100:.1f}%"],
        ["Median 30-day change", pct(worlds.change_30d.median()), pct(conv.change_30d.median()), pct(worlds.loc[worlds.location.eq("South America"), "change_30d"].median())],
        ["Median annualized volatility", f"{worlds.ann_vol_full.median()*100:.1f}%", f"{conv.ann_vol_full.median()*100:.1f}%", f"{worlds.loc[worlds.location.eq('South America'), 'ann_vol_full'].median()*100:.1f}%"],
    ]
    story.append(safe_table(desc, [54 * mm, 40 * mm, 42 * mm, 40 * mm]))
    story.append(claim("Observed data", "The all-world price dispersion is inflated by launch-phase worlds. The converged-world CV is about 5%, consistent with the transaction-cost band around the law of one price."))
    story.append(fig(CHARTS / "sa_current_prices.png"))

    # 13
    story += [section_break(), H1(13, "Aggregate Market Indices")]
    story.append(claim("Observed data", f"The converged-world median index increased {pct(S['full_period_index_change'])} from the start to the end of the observation window. Regional medians move together, with temporary gaps rather than permanently separate price regimes."))
    story.append(fig(CHARTS / "regional_indices.png"))
    story.append(claim("Economic interpretation", "The co-movement is consistent with account-level TC mobility, while persistent short-lived region and world gaps reflect fees, timing, and local gp conditions."))

    # 14
    story += [section_break(), H1(14, "Trend Analysis")]
    story.append(claim("Observed data", "The broad panel shows a rising long-horizon path with material drawdowns and recoveries. The path is shared across mature worlds and is not well represented by a deterministic linear trend."))
    story.append(claim("Statistical relationship", "Daily returns are serially dependent, but the price level remains non-stationary. Trend-following summaries can describe recent direction; they do not establish a stationary long-run target."))
    story.append(claim("Analyst judgement", "The useful trend signal is cross-world breadth and relative displacement, not a projection of a trailing level average. A common upward move does not by itself imply continued appreciation."))

    # 15
    story += [section_break(), H1(15, "Time-Series Properties")]
    tsrows = [
        ["Test / diagnostic", "Result", "Interpretation"],
        ["ADF by world", "p-values 0.08-0.66", "Fails to reject unit root for every world"],
        ["KPSS by world", "Rejects stationarity for every world", "Agrees that the level is non-stationary"],
        ["Ljung-Box on returns", "Rejects independence", "Returns contain serial structure"],
        ["Relative-price half-life", "Approximately 21 days", "World gaps mean-revert even though the common level does not"],
    ]
    story.append(safe_table(tsrows, [48 * mm, 50 * mm, 78 * mm]))
    story.append(claim("Forecast", "For a non-stationary level, the honest central forecast at every horizon is the current price. Pulling the price toward a trailing mean would impose structure rejected by both stationarity tests."))

    # 16
    story += [section_break(), H1(16, "Seasonality")]
    story.append(claim("Observed data", "Scheduled XP/Skill and Rapid Respawn events cluster seasonally, as do update releases. Calendar averages therefore combine recurring player behavior with event scheduling and other global date effects."))
    story.append(claim("Statistical relationship", "The observed event-return differences are not separately identified from same-date global shocks. Day-of-week or month-of-year patterns should not be interpreted causally without an exogenous world-specific contrast."))
    story.append(claim("Analyst judgement", "Seasonal naive forecasts are retained as a benchmark rather than a structural model. Across South American backtests, random walk and seven-day seasonal naive errors are similar enough that neither warrants overriding the current-price central forecast."))

    # 17
    story += [section_break(), H1(17, "Event Studies")]
    story.append(claim("Statistical relationship", "On converged worlds, XP/Skill event days average 0.28 percentage points lower daily returns than non-event days (p<0.001), Rapid Respawn days average 0.21 points lower (p<0.001), and the 14 days before updates average 0.06 points higher (p=0.01)."))
    story.append(fig(CHARTS / "event_associations.png"))
    story.append(claim("Economic interpretation", "Two mechanisms fit the negative event-day sign: TC holders may sell into event-related gp demand, or players may divert gp toward consumables. The data cannot distinguish the mechanisms."))
    story.append(claim("Limitation", "World fixed effects leave all other same-day global influences in the event coefficient. World plus date fixed effects absorb the event indicators completely."))

    # 18
    story += [section_break(), H1(18, "Cross-World Integration")]
    story.append(claim("Documented mechanic", "TC can move across worlds at the account level, making cross-world price differences directly tradable without moving a character."))
    story.append(claim("Observed data", "The latest converged-world cross-sectional dispersion is approximately 5%, close to the fee-implied no-arbitrage band. Regional and world indices co-move over the full sample."))
    story.append(claim("Statistical relationship", "Relative deviations mean-revert with an approximately 21-day half-life, while the shared level remains non-stationary. Relative prices are therefore more predictable than absolute prices."))
    story.append(claim("Economic interpretation", "The market behaves like a partially integrated network of local gp pools connected by an account-level asset and bounded by transaction costs."))

    # 19
    story += [section_break(), H1(19, "Arbitrage Analysis")]
    story.append(claim("Statistical relationship", "The restoring force changes sign near a 4% relative-price gap. Gaps above 4% close faster as they widen; smaller gaps show no reliable closure."))
    story.append(fig(CHARTS / "arbitrage_band.png"))
    subrows = [["Era", "0-2%", "2-4%", "4-6%", "6-10%", ">10%"]]
    for era in ["Early", "Middle", "Late"]:
        d = arb_sub[arb_sub.era.eq(era)].set_index("gap_band")
        subrows.append([era] + [f"{d.loc[b, 'mean_pct']:+.3f}" if b in d.index else "n/a" for b in ["0-2%", "2-4%", "4-6%", "6-10%", ">10%"]])
    story.append(safe_table(subrows, [30 * mm] + [29 * mm] * 5))
    story.append(claim("Observed data", "The updated era split preserves the qualitative threshold in the pooled panel, although the magnitude varies across thirds of the sample. Values in the table are percentage points of next-day restoring movement."))
    story.append(claim("Analyst judgement", "A nominal gap above 4% is necessary but not sufficient for profitable arbitrage. Execution depth, price movement during account switching, offer cancellation risk, and the fee cap must be evaluated."))

    # 20
    story += [section_break(), H1(20, "World-Type and Regional Analysis")]
    story.append(fig(CHARTS / "pvp_prices.png"))
    regrows = [["Term", "Coefficient", "Robust SE", "p-value"]]
    for term in ["Optional PvP", "BattlEye since release cohort", "World age (years)", "Log corrected population", "South America", "Europe"]:
        r = cross_reg[cross_reg.term.eq(term)].iloc[0]
        regrows.append([term, f"{r.coefficient:+.4f}", f"{r.std_error:.4f}", f"{r.p_value:.3g}"])
    story.append(safe_table(regrows, [72 * mm, 34 * mm, 34 * mm, 34 * mm]))
    story.append(claim("Statistical relationship", "Optional PvP is associated with approximately +5.6% higher prices in the corrected converged-world cross-section (p<0.001)."))
    story.append(claim("Economic interpretation", "A plausible mechanism is weaker death-penalty gp sinks on Optional PvP worlds, allowing gp to accumulate faster. This mechanism is interpretive, not directly measured."))
    story.append(claim("Statistical relationship", "The BattlEye-since-release coefficient is about -4.5% (p=0.002), but the variable is a cohort marker strongly confounded with world vintage. World age is insignificant after controls."))

    # 21
    story += [section_break(), H1(21, "Young-World Analysis")]
    story.append(claim("Observed data", "Genuine launches and merge destinations have sharply different initial price regimes. Victoris opened at 1,023 gp/TC and Mystera at 1,320 gp/TC, while 2025 merge destinations such as Sombra, Terribra, Eclipta, Kalanta, Citra, Xymera, Blumera, Monstera, and Tempestera opened around 35,000-41,500 gp/TC."))
    story.append(fig(CHARTS / "provenance_first_price.png"))
    story.append(claim("Observed data", "The metadata classify 29 genuine launches and 20 merge destinations created within the price observation window. Dataset-entry date is not used as a launch indicator."))
    story.append(claim("Economic interpretation", "A genuine launch begins with a new local gp stock and fresh market formation. A merge destination inherits predecessor balances and therefore prints mature prices immediately."))

    # 22
    story += [section_break(), H1(22, "Merge and Transfer Analysis")]
    story.append(claim("Observed data", f"The merge register contains {S['merge_register_records']} destination events and {S['merge_predecessor_worlds']} predecessor worlds from 2014 through 2025."))
    story.append(claim("Limitation", "A before/after merge effect cannot be estimated from the archive because predecessor names have no price observations in the panel. Successor series begin after the merge."))
    story.append(claim("Observed data", f"The GuildStats transfer page yielded {S['recent_transfers']} recent observations; {S['cross_region_transfer_share']*100:.1f}% connect known worlds in different regions. This documents a second player-mobility channel beyond account-level TC movement."))
    story.append(fig(CHARTS / "transfer_net_flows.png"))
    story.append(claim("Limitation", "The transfer page is a recent tracked list rather than a complete historical flow panel. The chart is exploratory and is not used as a causal regressor."))

    # 23
    story += [section_break(), H1(23, "Liquidity and Microstructure")]
    story.append(claim("Observed data", "The archive records sell-side and buy-side executed quantities separately. Their sum is not labeled turnover because the same trade may appear on both sides."))
    story.append(claim("Observed data", "Standing order counts do not measure depth or demand. Placeholder bids can dominate order counts while remaining economically irrelevant. The true quoted spread is the best ask minus best bid; the difference between daily executed averages is a different statistic."))
    story.append(claim("Statistical relationship", "The established panel result finds lagged log traded quantity insignificant (p approximately 0.53). In the exploratory two-sided decomposition, sell and buy quantities enter with opposing signs, indicating that side-specific fields are not a stable single liquidity signal."))
    story.append(claim("Analyst judgement", "Order-book depth by price level, not order count, is the appropriate execution variable for an arbitrage strategy. Historical depth is unavailable, so executable capacity cannot be backtested."))

    # 24
    story += [section_break(), H1(24, "Technical Indicators")]
    tech = worlds[worlds.location.eq("South America")].copy()
    tech["rsi_label"] = pd.cut(tech.rsi14, [-np.inf, 30, 70, np.inf], labels=["Below 30", "30-70", "Above 70"])
    techrows = [["World", "Price", "20d SMA", "50d SMA", "RSI(14)", "30d ann. vol"]]
    for _, r in tech.sort_values("rsi14").head(6).iterrows():
        techrows.append([r.world, f"{r.current_price:,.0f}", f"{r.sma20:,.0f}", f"{r.sma50:,.0f}", f"{r.rsi14:.1f}", f"{r.ann_vol_30d*100:.1f}%"])
    story.append(safe_table(techrows, [32 * mm, 28 * mm, 28 * mm, 28 * mm, 25 * mm, 35 * mm]))
    story.append(claim("Observed data", "Moving averages, RSI, MACD, and rolling volatility summarize recent path and dispersion. They do not overcome level non-stationarity and are not treated as standalone valuation signals."))
    story.append(claim("Analyst judgement", "Technical indicators are useful for execution timing and risk sizing, but the report rating does not rest on them."))

    # 25
    story += [section_break(), H1(25, "Economic Valuation")]
    story.append(claim("Analyst judgement", "Absolute fundamental value cannot be estimated from the accessible data because gp stock, gp income, and TC supply are unobserved. Any discounted-cash-flow analogue would be artificial."))
    story.append(claim("Statistical relationship", "Relative valuation is better identified. A world's log-price deviation from the converged cross-world mean has a stable restoring relationship outside the approximately 4% cost band."))
    story.append(claim("Economic interpretation", "A high local gp-per-TC price can reflect abundant local gp, strong TC demand, weaker gp sinks, or temporary order-book conditions. The model identifies relative expensiveness, not its unique structural cause."))
    story.append(claim("Hypothesis", "Persistent upward movement in the common level may be consistent with gp inflation, but the mechanism is indirect and cannot be measured with the available sources."))

    # 26
    story += [section_break(), H1(26, "Econometric Models")]
    pr = [["Model", "Term", "Coefficient", "Two-way clustered SE", "p-value"]]
    for _, r in panel_reg.iterrows():
        pr.append([r["model"], r["term"], f"{r.coefficient:+.4f}", f"{r.std_error:.4f}", f"{r.p_value:.3g}"])
    story.append(safe_table(pr, [46 * mm, 61 * mm, 23 * mm, 26 * mm, 20 * mm]))
    story.append(claim("Statistical relationship", "With world and date fixed effects plus two-way clustered standard errors, lagged relative-price deviation is -0.116 (p<0.001). This aligns with strong relative mean reversion and is robust to common date shocks."))
    story.append(claim("Observed data", "The two-way cluster estimator combines world-cluster and date-cluster covariance and subtracts observation-level overlap. It addresses dependence within worlds and across worlds on shared dates."))
    story.append(claim("Limitation", "Worlds are linked through arbitrage, so even two-way clustering may not fully capture network dependence. A spatial or price-network lag specification remains a useful extension."))

    # 27
    story += [section_break(), H1(27, "Forecasts")]
    story.append(claim("Forecast", "Each South American world uses a bootstrapped random walk with a shrunk, capped daily drift and no imposed level mean reversion. Every horizon distribution is recentered so its median equals the latest observed price exactly."))
    story.append(fig(CHARTS / "forecast_example.png"))
    bench = benchmarks.groupby("horizon")[["random_walk_MAPE", "seasonal_naive_MAPE"]].median().reset_index()
    br = [["Horizon", "Random walk median MAPE", "Seasonal naive median MAPE"]]
    for _, r in bench.iterrows():
        br.append([r.horizon, f"{r.random_walk_MAPE*100:.1f}%", f"{r.seasonal_naive_MAPE*100:.1f}%"])
    story.append(safe_table(br, [58 * mm, 59 * mm, 59 * mm]))
    story.append(claim("Forecast", "The median forecast is intentionally uninformative about direction; interval width is the primary output. Benchmark errors support retaining random walk as the reference rather than imposing a trailing-mean target."))
    story.append(fig(CHARTS / "forecast_widths.png"))

    # 28
    story += [section_break(), H1(28, "Scenario Analysis")]
    sa6 = forecasts[forecasts.horizon_days.eq(180)]
    scen = [
        ["Scenario", "Definition", "Cross-world reading"],
        ["Central", "Current price at each horizon", "No directional edge in the common level"],
        ["Favorable-price decline", "10th or 2.5th percentile path", "TC becomes cheaper in gp; useful to gp-funded buyers"],
        ["Adverse-price increase", "90th or 97.5th percentile path", "TC becomes more expensive in gp; risk to gp-funded buyers"],
        ["Relative convergence", "Local gap outside 4% band closes", "World-specific opportunity independent of common direction"],
    ]
    story.append(safe_table(scen, [41 * mm, 63 * mm, 72 * mm]))
    story.append(claim("Forecast", f"Across South American worlds, the median six-month 95% interval width is {((sa6.p975_gp_per_TC-sa6.p025_gp_per_TC)/sa6.current_price_gp_per_TC).median()*100:.0f}% of current price. World-level ranges vary materially and are tabulated in Appendix B."))
    story.append(claim("Analyst judgement", "Scenario planning should size positions to interval width and liquidity, then evaluate relative-price convergence separately from the common-level scenario."))

    # 29
    story += [section_break(), H1(29, "Risk Analysis")]
    risks = [
        ["Risk", "Mechanism", "Control"],
        ["Common-level uncertainty", "Non-stationary gp-per-TC level", "Use current price as central forecast; size to intervals"],
        ["Execution and fees", "Approximately 4% round-trip offer fees plus book movement", "Require gap beyond fees and inspect true depth"],
        ["Liquidity illusion", "Order counts include placeholder bids", "Use price-level amount, not counts"],
        ["Data outage", "-1 sentinels and failed scans", "Missing-value handling and fallback screens"],
        ["Cohort confounding", "BattlEye since release tracks vintage", "Interpret as cohort marker"],
        ["Event confounding", "Global events overlap date effects", "No causal claims"],
        ["Population bias", "04:45 UTC snapshot rotates regions", "Region factors; collect full histories"],
        ["Network dependence", "Worlds linked by TC arbitrage and player transfers", "Two-way clustering; future network model"],
    ]
    story.append(safe_table(risks, [42 * mm, 72 * mm, 62 * mm]))
    story.append(claim("Analyst judgement", "The dominant risk is not a single technical setup but mis-specifying the common level as stationary. The second is assuming a visible price gap is executable after fees and depth."))

    # 30
    story += [section_break(), H1(30, "Robustness Tests")]
    rob = [
        ["Test", "Result", "Implication"],
        ["Alternative price measures", "0.49%-2.28% average differences", "Core results are not driven by price construction"],
        ["Two-way clustered errors", "Lagged deviation remains p<0.001", "Relative mean reversion survives common-date dependence"],
        ["Arbitrage era splits", "Qualitative threshold preserved; magnitude varies", "Band is not solely a pooled-period artifact"],
        ["ADF + KPSS", "Both support non-stationary levels", "Random-walk central forecast is conservative"],
        ["Population correction", "Coefficient remains insignificant", "Null remains uncertain because factors are regional estimates"],
        ["Random walk benchmark", "Competitive with seasonal naive", "No evidence for level mean reversion"],
    ]
    story.append(safe_table(rob, [47 * mm, 60 * mm, 69 * mm]))
    story.append(claim("Analyst judgement", "The strongest conclusion is the transaction-cost band in relative prices. The weakest quantitative area is population, where measurement quality remains insufficient for a decisive coefficient."))

    # 31
    story += [section_break(), H1(31, "Limitations")]
    limitations = [
        "The price archive is a third-party mirror rather than an official CipSoft feed.",
        "UTC dates approximate the server-save economic day.",
        "Predecessor worlds have no archived prices, so merge effects are untestable.",
        "Historical order-book depth is unavailable; executable arbitrage capacity cannot be backtested.",
        "Global events are collinear with date fixed effects and cannot support causal attribution.",
        "Population correction uses region factors estimated from 15 worlds, not full per-world histories.",
        "Recent transfer observations are not a complete historical flow panel.",
        "Cross-world p-values may remain optimistic because the market is a connected network.",
        "No accessible series measures gp stock, gp income, or TC supply.",
    ]
    for item in limitations:
        story.append(claim("Limitation", item))

    # 32
    story += [section_break(), H1(32, "Final Conclusion")]
    story.append(claim("Analyst judgement", "<b>Overall rating: Neutral.</b> Confidence is 79/100. The rating reflects strong confidence in relative-price integration and weak confidence in any directional statement about the common gp level."))
    story.append(claim("Statistical relationship", "The market's most defensible quantitative result is a law-of-one-price relationship with an approximately 4% transaction-cost band and a relative-deviation half-life near 21 days."))
    story.append(claim("Forecast", "Current price is the median absolute-price forecast at every horizon. For South American worlds, uncertainty expands rapidly, making interval width more decision-useful than the central path."))
    story.append(claim("Analyst judgement", "The practical edge is relative valuation with disciplined execution, not prediction of the shared level. Population histories, server-save alignment, historical depth, and full transfer flows would most improve the next iteration."))

    # 33
    story += [section_break(), H1(33, "Data Dictionary")]
    dictionary = [
        ["Variable", "Unit / type", "Definition"],
        ["price", "gp per TC", "Mean of valid daily executed side averages; screened order-book fallback"],
        ["return", "log points/day", "First difference of log price within world"],
        ["deviation", "log points", "World log price minus same-day converged-world mean log price"],
        ["lagged_deviation", "log points", "Previous observed day's deviation"],
        ["day_sold", "TC/day", "Sell-side executed quantity; reported separately"],
        ["day_bought", "TC/day", "Buy-side executed quantity; reported separately"],
        ["converged", "Boolean", "At least 200 prices, regular type, not a genuine launch in-window"],
        ["launch_in_window", "Boolean", "Created within panel and absent from merge register"],
        ["merge_flag", "Boolean", "Active world appears as a destination in the merge register"],
        ["corrected_population_estimate", "players", "TibiaData snapshot multiplied by region correction factor"],
        ["prediction interval", "gp per TC", "Bootstrap quantiles around the random-walk forecast"],
    ]
    story.append(safe_table(dictionary, [48 * mm, 35 * mm, 93 * mm]))

    # 34
    story += [section_break(), H1(34, "Source and Endpoint Inventory")]
    endpoints = [
        ["Source", "Endpoint / path", "Output", "Use"],
        ["GitHub", "data/market/world/<World>/<world>_tibia_coins.json", "Historical MarketValues JSON", "Primary price panel"],
        ["TibiaMarket.top", "/item_history", "Intraday MarketValues", "Schema and history validation"],
        ["TibiaMarket.top", "/events", "Global daily event labels", "Event calendar"],
        ["TibiaMarket.top", "/market_board", "Current order book", "Field semantic validation"],
        ["TibiaMarket.top", "/item_metadata", "NPC anchors and metadata", "Economic context"],
        ["TibiaData v4", "/worlds", "World attributes and current players online", "Metadata and population snapshot"],
        ["GuildStats", "/worlds", "Creation dates, region, type, record online", "Creation provenance"],
        ["GuildStats", "/servers-merge", "77 merge destinations", "Lineage"],
        ["GuildStats", "/online-counter?world=<Name>", "Population history", "15-world validation; future completion"],
        ["GuildStats", "/world-transfer", "Recent character transfers", "Exploratory linkage"],
        ["Official Tibia news", "Release pages", "Update dates", "Update calendar"],
    ]
    story.append(safe_table(endpoints, [30 * mm, 60 * mm, 43 * mm, 43 * mm]))
    story.append(claim("Documented mechanic", "TibiaVIP population paths are not used because robots.txt disallows the relevant endpoints."))

    # 35
    story += [section_break(), H1(35, "Methodological Appendix")]
    story.append(H2("Panel construction"))
    story.append(claim("Observed data", "Unix timestamps are converted to UTC and floored to day. The final price-bearing observation is retained for each world-day. Invalid sentinels become missing before all calculations."))
    story.append(H2("Cohort construction"))
    story.append(claim("Observed data", "A genuine launch is created during the observation window and absent from the merge register. A converged world has at least 200 valid prices, regular game-world type, and is not a genuine launch in-window."))
    story.append(H2("Fixed-effects estimator"))
    story.append(claim("Observed data", "The dependent variable is daily log return. Regressors are lagged relative-price deviation and lagged log sell-side and buy-side quantities. World and date effects are removed by alternating demeaning. Standard errors are clustered by world and date."))
    story.append(H2("Arbitrage bins"))
    story.append(claim("Observed data", "Absolute lagged relative-price deviations are grouped into 0-2%, 2-4%, 4-6%, 6-10%, and above 10% bins. Restoring movement is the signed next-day change that reduces the gap."))
    story.append(H2("Forecast simulation"))
    story.append(claim("Forecast", "Daily log returns from up to the latest 730 observations are clipped at +/-10%, centered, and resampled for 3,000 paths. The sample drift is shrunk by 90% and capped at +/-0.05% per day. Each horizon distribution is recentered to the current price so the median is exactly current price."))
    story.append(H2("Reproducibility"))
    story.append(claim("Observed data", "The delivered analysis script rebuilds metadata, cleaning, regressions, arbitrage splits, forecasts, benchmarks, transfer summaries, charts, and the PDF from the cited sources. Random simulations use a fixed seed of 20260730."))

    # Appendix A
    story += [PageBreak(), P("Appendix A  Reference Table for All 93 Worlds", "AppendixH1")]
    story.append(claim("Observed data", "The table lists each world's current metadata and latest cleaned price. Creation and lineage come from GuildStats; region and current attributes come from TibiaData."))
    ref_rows = [["World", "Region", "PvP", "Created", "Merge", "Launch", "Obs.", "Latest price", "Corrected pop."]]
    m2 = meta.set_index("name")
    for _, r in worlds.sort_values("world").iterrows():
        wm = m2.loc[r.world]
        ref_rows.append([
            r.world,
            r.location,
            r.pvp_type,
            str(wm.created)[:10],
            "Yes" if bool(wm.merge_flag) else "No",
            "Yes" if bool(wm.launch_in_window) else "No",
            f"{int(r.observations):,}",
            f"{r.current_price:,.0f}",
            f"{r.corrected_population_estimate:,.0f}",
        ])
    story.append(safe_table(ref_rows, [22 * mm, 23 * mm, 29 * mm, 22 * mm, 14 * mm, 14 * mm, 14 * mm, 20 * mm, 20 * mm], repeatRows=1))

    # Appendix B
    story += [PageBreak(), P("Appendix B  South American World Detail and Forecasts", "AppendixH1")]
    story.append(claim("Forecast", "Each world page reports current statistics, a historical chart, and 14/30/90/180-day bootstrap prediction intervals. Median forecasts equal the current price by construction."))
    for world in sorted(forecast_paths):
        r = worlds[worlds.world.eq(world)].iloc[0]
        fw = forecasts[forecasts.world.eq(world)].sort_values("horizon_days")
        story += [PageBreak(), P(world, "WorldTitle")]
        info = [
            ["Metric", "Value", "Metric", "Value"],
            ["Latest price", gp(r.current_price), "30-day change", pct(r.change_30d)],
            ["90-day change", pct(r.change_90d), "Annualized volatility", f"{r.ann_vol_full*100:.1f}%"],
            ["20-day SMA", gp(r.sma20), "50-day SMA", gp(r.sma50)],
            ["RSI(14)", f"{r.rsi14:.1f}", "Current cross-world deviation", f"{r.current_deviation*100:+.1f}%"],
            ["Median sell-side quantity", f"{r.median_day_sold:,.0f} TC/day", "Median buy-side quantity", f"{r.median_day_bought:,.0f} TC/day"],
            ["PvP / transfer", f"{r.pvp_type} / {r.transfer_type}", "Provenance", "Launch" if bool(r.launch_in_window) else ("Merge destination" if bool(r.merge_flag) else "Mature/other")],
        ]
        story.append(safe_table(info, [39 * mm, 49 * mm, 42 * mm, 46 * mm]))
        story.append(Spacer(1, 3 * mm))
        story.append(fig(CHARTS / f"sa_{world.lower()}.png", 176 * mm))
        fr = [["Horizon", "Median", "80% interval", "95% interval"]]
        for _, q in fw.iterrows():
            fr.append([
                q.horizon,
                gp(q.median_gp_per_TC),
                f"{q.p10_gp_per_TC:,.0f} - {q.p90_gp_per_TC:,.0f} gp/TC",
                f"{q.p025_gp_per_TC:,.0f} - {q.p975_gp_per_TC:,.0f} gp/TC",
            ])
        story.append(safe_table(fr, [34 * mm, 42 * mm, 50 * mm, 50 * mm]))
        story.append(claim("Forecast", "The central path is flat by construction. Use the interval width for position sizing; the distribution does not imply a fundamental price target.", "Small"))

    # Appendix C
    story += [PageBreak(), P("Appendix C  Deliverables List", "AppendixH1")]
    deliverables = [
        ["Deliverable", "Purpose"],
        [PDF_PATH.name, "Single standalone report with 35 numbered sections and appendices"],
        ["world_reference_table.csv", "All-world statistics and current indicators"],
        ["south_america_forecasts.csv", "136 South American horizon-world forecast rows"],
        ["clean_daily_panel.csv", "Reproducible cleaned daily panel"],
        ["world_metadata.csv", "World attributes, creation dates, lineage, and corrected population"],
        ["world_merge_register.csv", "77 merge destinations and 196 predecessors"],
        ["recent_character_transfers.csv", "Recent GuildStats transfer observations"],
        ["panel_regressions_two_way_clustered.csv", "World and world-plus-date fixed-effects estimates"],
        ["cross_section_corrected_population.csv", "Corrected population and world-type cross-section"],
        ["analyze_market.py", "Data construction and statistical analysis"],
        ["build_report.py", "Chart and PDF generation"],
    ]
    story.append(safe_table(deliverables, [75 * mm, 101 * mm]))
    story.append(claim("Observed data", "All figures include units, source, date or window context, legend where applicable, axis labels, and a transformation or exclusion note. Tables use wrapped paragraph cells to prevent overflow."))
    return story


def main():
    create_charts()
    doc = ReportDoc(str(PDF_PATH))
    doc.multiBuild(build_story())
    print(PDF_PATH)


if __name__ == "__main__":
    main()
